/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TextField/index.ts":
/*!****************************!*\
  !*** ./TextField/index.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TextField: () => (/* binding */ TextField)\n/* harmony export */ });\nclass TextField {\n  constructor() {}\n  init(context, notifyOutputChanged, state, container) {\n    this.container = container;\n    this.notifyOutputChanged = notifyOutputChanged;\n    // Create an input element for text entry\n    this.inputElement = document.createElement(\"input\");\n    this.inputElement.type = \"text\"; // Default to text type\n    this.inputElement.classList.add(\"textInputControlTwoOptionsCss\");\n    this.inputElement.style.width = \"100%\";\n    // Apply initial styles and read-only behavior\n    this.applyStyles(context);\n    // Attach input change event\n    this.inputElement.addEventListener(\"input\", event => {\n      var target = event.target;\n      context.parameters.sampleProperty.raw = target.value;\n      this.notifyOutputChanged();\n    });\n    // Attach input element to container\n    this.container.appendChild(this.inputElement);\n  }\n  updateView(context) {\n    // Update the input field value and apply styles\n    this.inputElement.value = context.parameters.sampleProperty.raw || \"\";\n    this.applyStyles(context);\n  }\n  applyStyles(context) {\n    var toggleValue = context.parameters.toggleColor.raw || false;\n    var numberValue = context.parameters.sampleNumber.raw || 0;\n    var isReadOnly = context.parameters.readOnlyFlag.raw || \"\";\n    // Apply background color based on conditions\n    if (toggleValue || numberValue > 80) {\n      this.inputElement.style.backgroundColor = \"red\";\n      this.inputElement.style.color = \"white\";\n    } else {\n      this.inputElement.style.backgroundColor = \"\";\n      this.inputElement.style.color = \"black\";\n    }\n    // Make the field read-only based on the readOnlyFlag parameter\n    // Make the field read-only based on the readOnlyFlag parameter being \"true\"\n    this.inputElement.readOnly = isReadOnly.toLowerCase() === \"true\";\n  }\n  getOutputs() {\n    return {\n      sampleProperty: this.inputElement.value\n    };\n  }\n  destroy() {\n    // Cleanup if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TextField/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./TextField/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('TextField.TextField', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TextField);
} else {
	var TextField = TextField || {};
	TextField.TextField = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TextField;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}